import React from 'react';
import {
  View,
  Text
} from 'react-native';
import HomeScreen from './HomeScreen';
import LoginScreen from './LoginScreen';
import RegistrationScreen from './RegistrationScreen';
import { createDrawerNavigator } from 'react-navigation-drawer';
import { createAppContainer } from 'react-navigation';
import ProfileScreen from './ProfileScreen';
import MyCollectionScreen from './MyCollectionScreen';
import customNavProf from '../components/ProfileComponent'

const DrawerNavigator = createDrawerNavigator({

  Home: {
    screen: HomeScreen,
  },
  MyCollection: {
    screen: MyCollectionScreen
  },
  Profile: {
    screen: ProfileScreen
  },
}, {
  contentComponent: (props) => customNavProf(props),
  drawerBackgroundColor: 'white',
  drawerType: 'slide',
  contentOptions: {
    activeTintColor: 'white',
    activeBackgroundColor: '#87B940',
    activeLabelStyle: { fontFamily: 'Montserrat-Regular' }
  }
});

const AppNav = createAppContainer(DrawerNavigator);

export default class AppStackView extends React.Component {


  render() {
    return (
      <AppNav></AppNav>
    )
  }
}