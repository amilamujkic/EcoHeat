import React from 'react';
import {
    View, StyleSheet, Image, Text, TextInput, TouchableOpacity
} from 'react-native';
import { ScrollView } from 'react-native-gesture-handler';
import * as firebase from "firebase"


export default class RegistrationScreen extends React.Component {

    state = {

    }
    render() {
        return (
            <View>
                <ScrollView>
                    <View style={styles.container}>
                        <View style={styles.containerLogo}>
                            <Image style={styles.logo} source={require('../assets/logo.png')}></Image>
                            <Text style={styles.title}>EcoHeat</Text>
                            <Text style={styles.subtitle}>make a balance</Text>
                        </View>

                        <Text textContentType={'email'} autoCompleteType={'email'} style={styles.label}>Email</Text>
                        <TextInput onChangeText={email => this.setState({ email })} style={styles.input}></TextInput>

                        <Text style={styles.label}>Full Name</Text>
                        <TextInput onChangeText={fullName => this.setState({ fullName: fullName })} style={styles.input}></TextInput>

                        <Text style={styles.label}>Username</Text>
                        <TextInput style={styles.input}></TextInput>

                        <Text style={styles.label}>Address</Text>
                        <TextInput style={styles.input}></TextInput>

                        <Text style={styles.label}>Create Password</Text>
                        <TextInput onChangeText={password => this.setState({ password: password })} secureTextEntry={true} style={styles.input}></TextInput>

                        <View style={styles.containerButton}>
                            <TouchableOpacity onPress={() => this.registerUser(this.state.email, this.state.password, this.state.fullName)} style={styles.button}><Text style={styles.buttonText}>Create account</Text></TouchableOpacity>
                            <Text style={styles.changeText}>Have an account? Sign in</Text>
                        </View>
                    </View>
                </ScrollView>
            </View>
        )
    }

    registerUser = (email, password, name) => {
        firebase.auth().createUserWithEmailAndPassword(email, password).then(res => {
            if (res != null) {
                this.props.navigation.navigate('App')
                res.user.updateProfile({
                    displayName: name
                }).then(usr => {

                })
            } else {

            }
        })
    }
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#87B940',
        display: 'flex',
        height: '100%',
    },
    containerLogo: {
        display: 'flex',
        alignItems: 'center'
    },
    logo: {
        width: 100,
        height: 100,
        marginTop: 40
    },
    title: {
        fontSize: 24,
        color: 'white',
        fontFamily: 'Montserrat-SemiBold',

    },
    subtitle: {
        fontSize: 18,
        color: 'white',
        fontFamily: 'Montserrat-Light',
        marginBottom: 32
    },
    label: {
        fontSize: 16,
        color: 'white',
        fontFamily: 'Montserrat-SemiBold',
        marginLeft: 24

    },
    input: {
        backgroundColor: '#aacc7b',
        marginLeft: 24,
        marginRight: 24,
        marginTop: 16,
        marginBottom: 24,
        borderRadius: 8
    },
    containerButton: {
        display: 'flex',
        alignItems: 'center'
    },
    button: {
        width: '60%',
        height: 100,
        backgroundColor: 'white',
        height: 56,
        borderRadius: 8,
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 24
    },
    buttonText: {

        fontSize: 18,
        color: 'black',
        fontFamily: 'Montserrat-SemiBold',
    },
    changeText: {

        fontSize: 12,
        color: 'white',
        fontFamily: 'Montserrat-SemiBold',
        marginTop: 12,
        marginBottom: 24
    }
})