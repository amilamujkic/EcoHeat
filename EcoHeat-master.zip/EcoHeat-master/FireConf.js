
export default {
    firebaseConfig: {
        apiKey: "AIzaSyBhiE5VLYWfaERcxEiei_EGBf07rsp5ErU",
        authDomain: "ecoheat-759ea.firebaseapp.com",
        databaseURL: "https://ecoheat-759ea.firebaseio.com",
        projectId: "ecoheat-759ea",
        storageBucket: "ecoheat-759ea.appspot.com",
        messagingSenderId: "464551450799",
        appId: "1:464551450799:web:3e1a751b161434ca959c5a"
    }
}