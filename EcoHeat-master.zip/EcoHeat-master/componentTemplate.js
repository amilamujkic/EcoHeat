import React from 'react';
import {
    View
} from 'react-native';


export default class Templete extends React.Component {


    render() {
        return (
            <View>
                <Text>DJESSSSS</Text>
            </View>
        )
    }
}