import React from 'react';
import {
  View,
  Text
} from 'react-native';
import HomeScreen from './src/views/HomeScreen';
import LoginScreen from './src/views/LoginScreen';
import RegistrationScreen from './src/views/RegistrationScreen';
import { createAppContainer } from 'react-navigation';
import ProfileScreen from './src/views/ProfileScreen';
import MyCollectionScreen from './src/views/MyCollectionScreen';
import customNavProf from './src/components/ProfileComponent';
import AppStackView from './src/views/AppStackView';
import { createStackNavigator } from 'react-navigation-stack';
import * as firebase from "firebase";
import FireConf from './FireConf';


const AppStack = createStackNavigator({
  SignIn: {
    screen: LoginScreen
  },
  SignUp: {
    screen: RegistrationScreen
  },
  App: {
    screen: AppStackView
  },

},
  {
    headerMode: 'none',
    navigationOptions: {
      headerVisible: false,
    }
  })
const AppContainer = createAppContainer(AppStack)


export default class App extends React.Component {

  componentWillMount() {
    firebase.initializeApp(FireConf.firebaseConfig);

  }


  render() {
    return (
      <AppContainer />
    )
  }
}